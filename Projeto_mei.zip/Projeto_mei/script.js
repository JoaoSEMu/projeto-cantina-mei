const tabButtons = document.querySelectorAll('.tab-btn');
const tabContents = document.querySelectorAll('.tab-content');

function abrirAba(targetId) {
    tabButtons.forEach(btn => btn.classList.remove('active'));
    tabContents.forEach(content => content.classList.remove('active'));

    const botaoAtivo = document.querySelector(`.tab-btn[data-target="${targetId}"]`);
    const secaoAtiva = document.getElementById(targetId);

    if (botaoAtivo && secaoAtiva) {
        botaoAtivo.classList.add('active');
        secaoAtiva.classList.add('active');
    }
}

tabButtons.forEach(button => {
    button.addEventListener('click', () => {
        const target = button.getAttribute('data-target');
        abrirAba(target);
    });
});

const filterButtons = document.querySelectorAll('.filter-btn');
const categoryBlocks = document.querySelectorAll('.categoria-bloco');

filterButtons.forEach(button => {
    button.addEventListener('click', () => {
        filterButtons.forEach(btn => btn.classList.remove('active'));
        button.classList.add('active');

        const filterValue = button.getAttribute('data-filter');

        categoryBlocks.forEach(block => {
            if (filterValue === 'todos' || block.getAttribute('data-category') === filterValue) {
                block.style.display = 'block';
            } else {
                block.style.display = 'none';
            }
        });
    });
});